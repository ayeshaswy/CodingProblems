#!/usr/bin/python

import os.path
import sys

class priceTracker:
    def __init__(self, inputfile):
        self.filename = inputfile

    def __parseInput(self, line):
        pricedetail = []
        line = (line.rstrip(" ")).lstrip(" ")
        line = line.rstrip("\n")
        line = line.split("\t")
        for i in range(len(line)):
            line[i] = (line[i].rstrip(" ")).lstrip(" ")
        itemName = line[0]
        pricedetail.append(float(line[1]))
        if len(line) == 3:
            discount = line[2].split(" for ")
            for element in discount:
                pricedetail.append(float(element))
        else :
            pricedetail.append(1)
            pricedetail.append(float(line[1]))
        self.prices[itemName] = pricedetail


    def readPrices(self):
        self.prices = {}
        stop = False
        try:
            if os.path.exists(self.filename):
                fileObj = open(self.filename, "r")
        except IOError as err:
            print("Cannot open input file", err)
            sys.exit(1)

        while (not(stop) is True):
            line = fileObj.readline()
            if line == "":
                stop = True
                continue
            self.__parseInput(line)
        fileObj.close()
        return self.prices


class Billing():
    def __init__(self, inputfile):
        self.prices = {}
        self.filename = inputfile
    def __calculateTotalPrice(self, items):
        itemCount = {}
        itemList = list(items)
        for i in items:
            if i not in self.prices:
                return 0

        for i in items:
            if i not in itemCount:
                itemCount[i] = items.count(i)

        cost = 0
        for key in itemCount.keys():
            if itemCount[key] >= self.prices[key][1]:
                discountedItems = int(itemCount[key]/self.prices[key][1])
                remainingCount = itemCount[key] % self.prices[key][1]
                cost = cost + (discountedItems * self.prices[key][2]) + (remainingCount * self.prices[key][0])
            else:
                cost = cost + (itemCount[key] * self.prices[key][0])
        return cost

    def bill(self):
        stop = False
        try:
            if os.path.exists(self.filename):
                fileObj = open(self.filename, "r")
        except IOError as err:
            print("Unable to open input file", err)
            sys.exit(1)

        while(not(stop) is True):
            line = fileObj.readline()
            if line == "":
                stop = True
                continue
            line = line.rstrip("\n").rstrip(" ").lstrip(" ")
            cost = self.__calculateTotalPrice(line)
            if (cost == 0):
                print("Invalid input: ", line)
                continue
            print(line, ": ", cost)

        fileObj.close()

priceFile = input("Enter file with price Information\n")
inputFile = input("Enter input file with list of shopped items\n")
priceObj = priceTracker(priceFile)
billObj = Billing(inputFile)
billObj.prices = priceObj.readPrices()
billObj.bill()

